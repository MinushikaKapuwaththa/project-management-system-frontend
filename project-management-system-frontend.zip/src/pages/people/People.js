import React from 'react';
import './people.css';

export default function People() {
  return <h1 className='people'>PEOPLE</h1>;
}
