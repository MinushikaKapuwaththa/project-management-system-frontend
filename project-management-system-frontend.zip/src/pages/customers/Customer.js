import React from 'react';
import './customer.css';

export default function Customer() {
  return <h1 className='customer'>CUSTOMER</h1>;
}
