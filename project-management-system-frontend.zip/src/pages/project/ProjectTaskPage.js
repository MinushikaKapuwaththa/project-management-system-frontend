import React from "react";
import ProjectModuleLayout from "../../layouts/ProjectModuleLayout/ProjectModuleLayout";

export default function ProjectTaskPage() {
  return (
    <div>
      <ProjectModuleLayout />
      <h1>ProjectTaskPage</h1>
    </div>
  );
}
