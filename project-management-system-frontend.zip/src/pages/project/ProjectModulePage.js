import React from "react";
import "./ProjectModulePage.css";
import { Link } from "react-router-dom";
import ModuleProgressBar from "../../components/Module/ModuleProgressBar";
import ModuleRedioButton from "../../components/Module/ModuleRedioButton";





export default function ProjectModulePage() {
  return (
    <div>
      <div className="M1">
        <h1>Module</h1>
      </div>

      <div className="container shadow p-3 mb-5 bg-white rounded">
        <div className="b1">
          <Link to="moduleform">
            <button type="button" className="btn btn-primary">
              Creat Module
            </button>
          </Link>
        </div>

<div class="input-group">
  <div class="form-outline">
    <input type="search" id="form1" class="form-control" />
    <label class="form-label" for="form1">Search</label>
  </div>
  <button type="button" class="btn btn-primary">
    <i class="fas fa-search"></i>
  </button>
</div>



        <div className="row">
          <div className="col">
            <div>
              <h5>
                <b>Customer Module </b> - P1M1
              </h5>
            </div>
          </div>
          <div className="col">
            <div>
              <ModuleProgressBar />
            </div>
          </div>
          <div className="col">
            <div>
              stutus: <ModuleRedioButton />
            </div>
          </div>
          <div className="col">End date</div>
          <div className="col">Start Date</div>
          <div className="col">
          <Link to="/moduledetailsform">
            <button type="button" class="btn btn-link">
              Edit
            </button>
            </Link>
          </div>
        </div>
        <div className="row">
          <div className="col">
            <hr />
            <ul className="list-group list-group-flush">
              <li className="list-group-item">Task 01:</li>
              <li className="list-group-item">Task 02:</li>
            </ul>
          </div>
        </div>
      </div>






      {/* <div className="b1">
        <Link to="moduleform">
          <button type="button" className="btn btn-primary">
            Creat Module
          </button>
        </Link>
      </div> */}
      {/* <div className="row">
          <div className="col">
            <div>
              <h5>
                <b>Customer Module </b> - P1M1
              </h5>
            </div>
          </div>
          <div className="col">
            <div>
              <ModuleProgressBar />
            </div>
          </div>
          <div className="col">
            <div>
              stutus: <ModuleRedioButton />
            </div>
          </div>
          <div className="col">End date</div>
          <div className="col">Start Date</div>
        </div> */}

      {/* <div className="row">
          <div className="col">
            <hr />
            
          </div>
        </div> */}
    </div>
  );
}
