import React from 'react';
import './Home.css';

export default function Home() {

    return(
      <div>
    <h1>HOME PAGE</h1>
    <p> test project</p>
    
 
 

</div>





    ) ;

  }
  