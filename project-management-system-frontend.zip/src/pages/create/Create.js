import React from 'react';
import './create.css';

export default function Create() {
  return <h1 className='Create'>LIKE & SUBSCRIBE</h1>;
}
