import React from 'react';
import './companies.css';

export default function Companies() {
  return <h1 className='companies'>COMPANIES</h1>;
}
