import React from 'react';
import './ourteam.css';

export default function Ourteam() {
  return <h1 className='ourteam'>OURTEAM</h1>;
}
