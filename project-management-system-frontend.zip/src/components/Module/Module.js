import React, { Component } from 'react'
import './module.css'
//import Form from './Form'
//import { link } from 'react-router-dom'



// class module extends Component {
//     render() {
    
// 		return (
// 			<div className="module">
//                 <link to ={"./sideBar"}></link> 
// 				<Form />

//                 <h1>Hi</h1>
// 			</div>
// 		)
// 	}
// }

// export default module

