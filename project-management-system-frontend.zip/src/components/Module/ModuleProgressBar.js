import ProgressBar from 'react-bootstrap/ProgressBar';

function StripedExample() {
  return (
    <div>
      <ProgressBar striped variant="warning" now={60} />
    </div>
  );
}

export default StripedExample;