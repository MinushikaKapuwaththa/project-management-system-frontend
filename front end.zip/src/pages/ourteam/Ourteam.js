
import "./ourteam.css";
 import React from 'react'
 
 export default function Ourteam() {
   return (
     <div>Ourteam</div>
   );
 }
 
 
