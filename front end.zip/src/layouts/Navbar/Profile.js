// import React from 'react';
// import {  MDBCardBody, MDBCardImage,} from 'mdb-react-ui-kit';
// import "./Navbar.css"


// export default function Profile() {
//   return (
//     <div>
//               <MDBCardBody >
               
//                 <div className='profile'>
//                   <div className='profileImg' >
//                     <MDBCardImage
//                       style={{ width: '40px' }}
//                       className="img-fluid rounded-circle border border-dark border-3"
//                       src='https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-2.webp'
//                       alt='Generic placeholder image'
//                       fluid />
//                   </div > 
//                     { <div className='username'>
//                       <p> A B C Minushika <span>@minushikakapu</span></p>
//                       </div> }
             
//                 </div>
               
                
                 
//               </MDBCardBody>
            
        
    
//     </div>
//   );
// }