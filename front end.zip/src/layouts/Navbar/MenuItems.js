export const MenuItems = [
    {
      title: 'Companies',
      path: '/companies',
      cName: 'dropdown-link'
    },
    {
      title: 'People',
      path: '/people',
      cName: 'dropdown-link'
    },
    
  ];
  